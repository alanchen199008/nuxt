// user 用户
export const LOGIN = 'LOGIN' // 用户登录
export const OUT_LOGIN = 'OUT_LOGIN' // 用户退出
export const USER_INFO_UPDATA = 'USER_INFO_UPDATA' // 更新用户信息
