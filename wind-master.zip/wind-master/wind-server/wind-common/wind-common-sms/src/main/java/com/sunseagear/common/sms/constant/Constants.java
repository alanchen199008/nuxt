package com.sunseagear.common.sms.constant;

public interface Constants {
    String CLIENTA_ALIYUN = "aliyun"; //本地
}
