package com.sunseagear.common.disruptor;

/**
 * All rights Reserved, Designed By www.sunseagear.com
 *
 * @version V1.0
 * @title: LongEvent.java
 * @package com.sunseagear.common.disruptor.sms
 * @description: 内容传递 * @date: 2017年6月7日 下午11:17:40
 * @copyright: 2017 www.sunseagear.com Inc. All rights reserved.
 */
public class TaskEvent {
    private Task task;

    public Task getTask() {
        return task;
    }

    public void setTask(Task task) {
        this.task = task;
    }
}
