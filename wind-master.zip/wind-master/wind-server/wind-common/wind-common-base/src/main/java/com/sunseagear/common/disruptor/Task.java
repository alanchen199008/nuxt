package com.sunseagear.common.disruptor;

/**
 * All rights Reserved, Designed By www.sunseagear.com
 *
 * @version V1.0
 * @package com.sunseagear.common.disruptor
 * @title:
 * @description: 异步任务 * @date: 2018/9/28 10:06
 * @copyright: 2017 www.sunseagear.com Inc. All rights reserved.
 */
public interface Task {
    void run();
}
