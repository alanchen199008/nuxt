package com.sunseagear.common.datarule.constant;

public interface DataScopeConstant {

    String DEFAULT_FIELD = "organizationId";
    String DEFAULT_COLUMN = "organization_id";
    String DEFAULT_TABLE = "sys_organization";

}
