package com.sunseagear.common.oss.client;

/**
 * All rights Reserved, Designed By kjt.gzst.gov.cn
 *
 * @version V1.0
 * @title: IOSSClient.java
 * @description: 操作客户端虚类 * @date: 2017年8月11日 下午9:55:00
 * @copyright: 2017 kjt.gzst.gov.cn Inc. All rights reserved.
 */
public abstract class AbstractOSSClient implements IOSSClient {
    //protected abstract void init();
}
