package com.sunseagear.common.oss.constant;

public interface Constants {
    String CLIENT_LOCAL = "local"; //本地
    String CLIENTA_ALIYUN = "aliyun"; //本地
}
