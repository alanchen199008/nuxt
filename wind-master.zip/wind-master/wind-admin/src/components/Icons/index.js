import IconsCompontent from './Icons.vue'
const Icons = {
  install(Vue) {
    Vue.component('UiIcons', IconsCompontent)
  }
}
export default Icons
